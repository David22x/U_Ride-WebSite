const { Router } = require("express");
const aRouter = Router();
const ac = require("../controllers/admin.controller");
const { esAdmin } = require("../middlewares/auth.middleware");
const { autenticar } = require("../middlewares/auth.middleware");

aRouter.use(autenticar, esAdmin);

aRouter.get("/reportes", ac.listarReportes); // RF11
aRouter.get("/reportes/:id", ac.obtenerReporte); // RF11
aRouter.post("/acciones/advertir", ac.advertir); // RF11
aRouter.post("/acciones/suspender", ac.suspender); // RF11
aRouter.patch("/acciones/levantar/:estudianteId", ac.levantarSuspension); // RF11
aRouter.get("/historial/:estudianteId", ac.historial); // RF11

module.exports = aRouter;
