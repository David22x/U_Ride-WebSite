const { Solicitud, Viaje, Participacion, Pasajero } = require("../models");

function apiError(msg, status = 400) {
  const e = new Error(msg);
  e.status = status;
  return e;
}

exports.crear = async (usuarioId, viajeId) => {
  const pasajero = await Pasajero.findOne({
    where: {
      usuario_id: usuarioId,
    },
  });

  if (!pasajero) {
    throw new Error("Perfil de pasajero no encontrado");
  }

  const viaje = await Viaje.findByPk(viajeId);

  if (!viaje) {
    throw new Error("Viaje no encontrado");
  }

  const solicitudExistente = await Solicitud.findOne({
    where: {
      pasajeroId: pasajero.id,
      viajeId: viajeId,
    },
  });

  if (solicitudExistente) {
    throw apiError("Ya has solicitado un cupo para este viaje", 409);
  }

  return Solicitud.create({
    pasajeroId: pasajero.id,
    viajeId,
  });
};

exports.aceptar = async (solicitudId, conductorId) => {
  const solicitud = await Solicitud.findByPk(solicitudId, {
    include: ["viaje"],
  });
  if (!solicitud) throw new Error("Solicitud no encontrada.");
  if (solicitud.viaje.conductorId !== conductorId)
    throw new Error("Sin permiso.");
  if (solicitud.viaje.cuposDisponibles <= 0)
    throw new Error("Sin cupos disponibles.");
  await solicitud.update({ estado: "aceptada" });
  await solicitud.viaje.decrement("cuposDisponibles");
  await Participacion.create({
    viajeId: solicitud.viajeId,
    pasajeroId: solicitud.pasajeroId,
  });
  return solicitud;
};

exports.rechazar = async (solicitudId, conductorId) => {
  const solicitud = await Solicitud.findByPk(solicitudId, {
    include: ["viaje"],
  });
  if (!solicitud) throw new Error("Solicitud no encontrada.");
  if (solicitud.viaje.conductorId !== conductorId)
    throw new Error("Sin permiso.");
  return solicitud.update({ estado: "rechazada" });
};

exports.pendientes = async (conductorId) => {
  const solicitudes = await Solicitud.findAll({
    where: {
      estado: "pendiente",
    },
    include: [
      {
        model: Viaje,
        as: "viaje",
        where: {
          conductorId,
        },
      },
    ],
  });

  return solicitudes;
};
