const adminReporte = require("../services/reporte.service");

exports.listarReportes = async (req, res, next) => {
  try {
    res.json(await adminReporte.listarReportesAdmin(req.query));
  } catch (e) {
    next(e);
  }
};
exports.obtenerReporte = async (req, res, next) => {
  try {
    res.json(await adminReporte.obtenerReporte(req.params.id));
  } catch (e) {
    next(e);
  }
};
exports.advertir = async (req, res, next) => {
  try {
    res.json(await adminReporte.advertirEstudiante(req.usuario.id, req.body));
  } catch (e) {
    next(e);
  }
};
exports.suspender = async (req, res, next) => {
  try {
    res.json(await adminReporte.suspenderEstudiante(req.usuario.id, req.body));
  } catch (e) {
    next(e);
  }
};
exports.levantarSuspension = async (req, res, next) => {
  try {
    res.json(
      await adminReporte.levantarSuspension(
        req.usuario.id,
        req.params.estudianteId,
      ),
    );
  } catch (e) {
    next(e);
  }
};
exports.historial = async (req, res, next) => {
  try {
    res.json(await adminReporte.historialAcciones(req.params.estudianteId));
  } catch (e) {
    next(e);
  }
};
